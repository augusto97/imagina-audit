<?php
require_once dirname(__DIR__) . '/bootstrap.php';
Auth::requireAuth();

$db = Database::getInstance();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $limit = min(100, max(1, (int) ($_GET['limit'] ?? 50)));
    $offset = ($page - 1) * $limit;
    $search = trim($_GET['search'] ?? '');

    // Si la tabla está vacía Y existe data/vulnerabilities.json, sembramos
    // automáticamente. Reemplaza el legacy database/seed.php que fue eliminado
    // en P7-cleanup. Solo corre cuando count=0, así es idempotente.
    try {
        $count = (int) $db->scalar("SELECT COUNT(*) FROM vulnerabilities");
        if ($count === 0) {
            $seedFile = dirname(__DIR__, 2) . '/data/vulnerabilities.json';
            if (is_file($seedFile)) {
                $seedRows = json_decode(file_get_contents($seedFile), true);
                if (is_array($seedRows)) {
                    foreach ($seedRows as $row) {
                        $db->execute(
                            "INSERT INTO vulnerabilities (plugin_slug, plugin_name, affected_versions, severity, cve_id, description, fixed_in_version) VALUES (?, ?, ?, ?, ?, ?, ?)",
                            [
                                $row['pluginSlug'] ?? '',
                                $row['pluginName'] ?? '',
                                $row['affectedVersions'] ?? '',
                                $row['severity'] ?? 'medium',
                                $row['cveId'] ?? '',
                                $row['description'] ?? '',
                                $row['fixedInVersion'] ?? '',
                            ]
                        );
                    }
                    Logger::info('Vulnerabilities auto-seeded from data/vulnerabilities.json: ' . count($seedRows) . ' rows');
                }
            }
        }
    } catch (Throwable $e) {
        Logger::warning('Vulnerabilities auto-seed failed: ' . $e->getMessage());
    }

    $where = '1=1';
    $params = [];

    if ($search !== '') {
        $where .= " AND (plugin_slug LIKE ? OR plugin_name LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    try {
        $total = (int) $db->scalar("SELECT COUNT(*) FROM vulnerabilities WHERE $where", $params);
        $totalPages = (int) ceil($total / $limit);

        // Inline LIMIT/OFFSET con casts a int — MySQL en algunas versiones
        // rechaza placeholders ? en LIMIT cuando emulate_prepares está off.
        $rows = $db->query(
            "SELECT * FROM vulnerabilities WHERE $where ORDER BY created_at DESC LIMIT " . (int) $limit . " OFFSET " . (int) $offset,
            $params
        );

        $vulns = array_map(function ($row) {
            return [
                'id' => (int) $row['id'],
                'pluginSlug' => $row['plugin_slug'],
                'pluginName' => $row['plugin_name'],
                'affectedVersions' => $row['affected_versions'],
                'severity' => $row['severity'],
                'cveId' => $row['cve_id'] ?? '',
                'description' => $row['description'],
                'fixedInVersion' => $row['fixed_in_version'] ?? '',
                'createdAt' => $row['created_at'],
            ];
        }, $rows);

        Response::success([
            'vulnerabilities' => $vulns,
            'total' => $total,
            'page' => $page,
            'totalPages' => $totalPages,
        ]);
    } catch (Throwable $e) {
        Logger::error('vulnerabilities GET falló: ' . $e->getMessage());
        Response::error(Translator::t('admin_api.vulns.fetch_error') . ': ' . $e->getMessage(), 500);
    }
}

if ($method === 'POST') {
    $body = Response::getJsonBody();
    try {
        $db->execute(
            "INSERT INTO vulnerabilities (plugin_slug, plugin_name, affected_versions, severity, cve_id, description, fixed_in_version) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                $body['pluginSlug'] ?? '',
                $body['pluginName'] ?? '',
                $body['affectedVersions'] ?? '',
                $body['severity'] ?? 'medium',
                $body['cveId'] ?? '',
                $body['description'] ?? '',
                $body['fixedInVersion'] ?? '',
            ]
        );
        Response::success(['id' => (int) $db->lastInsertId()], 201);
    } catch (Throwable $e) {
        Response::error(Translator::t('admin_api.vulns.create_error'), 500);
    }
}

if ($method === 'PUT') {
    $body = Response::getJsonBody();
    $id = $body['id'] ?? 0;
    if (!$id) Response::error(Translator::t('admin_api.common.id_required'));

    try {
        $db->execute(
            "UPDATE vulnerabilities SET plugin_slug=?, plugin_name=?, affected_versions=?, severity=?, cve_id=?, description=?, fixed_in_version=? WHERE id=?",
            [
                $body['pluginSlug'] ?? '',
                $body['pluginName'] ?? '',
                $body['affectedVersions'] ?? '',
                $body['severity'] ?? 'medium',
                $body['cveId'] ?? '',
                $body['description'] ?? '',
                $body['fixedInVersion'] ?? '',
                $id,
            ]
        );
        Response::success();
    } catch (Throwable $e) {
        Response::error(Translator::t('admin_api.vulns.update_error'), 500);
    }
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? 0;
    if (!$id) Response::error(Translator::t('admin_api.common.id_required'));

    try {
        $db->execute("DELETE FROM vulnerabilities WHERE id = ?", [(int) $id]);
        Response::success();
    } catch (Throwable $e) {
        Response::error(Translator::t('admin_api.vulns.delete_error'), 500);
    }
}

Response::error(Translator::t('api.common.method_not_allowed'), 405);
